package com.selenium.objectRepositories;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.utilities.BrowserUtils;

public class HolidaysPage {
	public WebDriver driver;
	public WebDriverWait wait;
	public HolidaysPage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//*[@id=\"collapsibleSection\"]/section[1]/div[1]/div/div/h2 ")
	WebElement banner;
	
	@FindBy(xpath="//a[@href='https://www.yatra.com/offer/dom/listing/holiday-deals']")
	WebElement holidays;
	
	@FindBy(xpath="//li[@title='Dubai Summer Special package (Land Only)']//span[@class='view-btn flR anim'][normalize-space()='View Details']")
	WebElement pack1;
	
	@FindBy(xpath="//a[@href='https://www.yatra.com/international-tour-packages/holidays-in-mauritius']//span[@class='wfull offer-content anim']//span[@class='details wfull bxs']//span[@class='flL view mt10']//span[@class='view-btn flR anim'][normalize-space()='View Details']")
	WebElement pack2;
	
	@FindBy(xpath="//a[@href='https://www.yatra.com/international-tour-packages/holidays-in-singapore?utm_source=banners&utm_medium=banners&utm_campaign=singapore_tourism']//span[@class='wfull offer-content anim']//span[@class='details wfull bxs']//span[@class='flL view mt10']//span[@class='view-btn flR anim'][normalize-space()='View Details']")
	WebElement pack3;

	public String getHolidayWindow() {
		return BrowserUtils.getCurrentWindowHandle(driver);
	}
	public boolean verifyHolidayPageTitle() {
		String title = driver.getTitle();
		if(title.equals("Domestic Flights Offers | Deals on Domestic Flight Booking | Yatra.com")) {
			System.out.println("Validated");
			return true;
		}
		else {
			System.out.println("Not Validated");
			return false;
		}
	}
	
	public boolean verifyBannerText() {
		 wait.until(ExpectedConditions.visibilityOf(banner));
		 String actualText = banner.getText();
         System.out.println("Banner Text: " + actualText);
         
         if (actualText.equals("Great Offers & Amazing Deals")) {
       	  System.out.println("Banner is Validated");
       	  return true;
       	  
         }
         else {
       	  System.out.println("Banner is not Validated");
       	  return false;
         }
	}
	
	public void clickOnHolidays() {
		holidays.click();
	}
	
	public void clickPackage1() {
		pack1.click();
	}
	
	public void clickPackage2() {
		pack2.click();
	}
	public void clickPackage3() {
		pack3.click();
	}
	
	
}
