package com.selenium.objectRepositories;
import java.time.Duration;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.utilities.BrowserUtils;

public class HomePage {

    public WebDriver driver;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    @FindBy(xpath = "//*[@id=\"__next\"]/div/div[1]/div[1]/div[2]/div")
    WebElement loginPopup;
    
    @FindBy(xpath = "//*[@id=\"__next\"]/div/div[1]/div[1]/div[2]/div/section[2]/span/img")
    WebElement crossClick;
  
    @FindBy(xpath = "//div[contains(text(),'View all offers')]")
    WebElement allOffers;
    

    public void handleLoginPopupIfPresent() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
            if (loginPopup.isDisplayed()) {
                wait.until(ExpectedConditions.visibilityOf(crossClick));
                crossClick.click();
                System.out.println("Login popup appeared and was closed.");
            }
        } catch (NoSuchElementException | org.openqa.selenium.TimeoutException e) {
            // Popup not present or not visible within timeout
            System.out.println("Login popup did not appear.");
        }
    }

    
    
    public void clickAllOffers() {
        allOffers.click();
    }

    public String getHomePageWindow() {
        return BrowserUtils.getCurrentWindowHandle(driver);
    }

    public void switchToHolidays() {
        BrowserUtils.switchToMostRecentTab(driver);
    }
}
