package com.selenium.objectRepositories;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.utilities.BrowserUtils;

import java.time.Duration;

public class Package1 {
    WebDriver driver;

    public Package1(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//*[@id=\"leftSect\"]/h2")
    WebElement namePackage1;

    @FindBy(xpath = "//*[@id=\"main-container\"]/div[2]/div/div/div[1]/div[2]/div/span[2]")
    WebElement pricePackage1;

    public String switchToPackageTab() {
        return BrowserUtils.switchToMostRecentTab(driver);
    }

    public String getDetailName() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(namePackage1));
        return namePackage1.getText();
    }

    public String getDetailPrice() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(pricePackage1));
        return pricePackage1.getText();
    }

    public void switchBackToHoliday(String holidayWindowId) {
        driver.close();
        driver.switchTo().window(holidayWindowId);
    }
}