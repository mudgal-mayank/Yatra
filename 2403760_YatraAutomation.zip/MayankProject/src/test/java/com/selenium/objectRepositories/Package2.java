package com.selenium.objectRepositories;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.utilities.BrowserUtils;

public class Package2 {
    WebDriver driver;

    public Package2(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    @FindBy(xpath = "/html/body/div[1]/div[4]/div/div/h1")
    WebElement namePackage2;

    @FindBy(xpath = "/html/body/div[1]/div[4]/div/div/ul[2]/li[1]/p[2]")
    WebElement pricePackage2;

   
    public String switchToPackageTab() {
        return BrowserUtils.switchToNewTabAndReturnHandle(driver);
    }

    public String getDetailName() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(namePackage2));
        return namePackage2.getText();
    }

    public String getDetailPrice() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(pricePackage2));
        return pricePackage2.getText();
    }

    public void switchBackToHoliday(String holidayWindowId) {
        driver.close();
        driver.switchTo().window(holidayWindowId);
    }
}