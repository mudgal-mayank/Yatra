
package com.selenium.objectRepositories;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.utilities.BrowserUtils;

import java.time.Duration;

public class Package3 {
    WebDriver driver;

    public Package3(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "/html/body/div[1]/div[4]/div/div/h1") // Update this XPath if different for Package 3
    WebElement namePackage3;

    @FindBy(xpath = "/html/body/div[1]/div[4]/div/div/ul[2]/li[1]/p[2]") // Update this XPath if different for Package 3
    WebElement pricePackage3;
    
    @FindBy(xpath = "//*[@id=\"booking_engine_modues\"]/li[1]/span[2]") 
    WebElement cross;

    public String switchToPackageTab() {
        return BrowserUtils.switchToMostRecentTab(driver);
    }
   

    public String getDetailName3() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(namePackage3));
        return namePackage3.getText();
    }

    public String getDetailPrice3() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(pricePackage3));
        return pricePackage3.getText();
    }

    public void switchBackToHoliday(String holidayWindowId) {
        driver.close();
        driver.switchTo().window(holidayWindowId);
    }
}
