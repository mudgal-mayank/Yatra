
package com.selenium.tests;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.selenium.objectRepositories.HolidaysPage;
import com.selenium.objectRepositories.HomePage;
import com.selenium.objectRepositories.Package1;
import com.selenium.objectRepositories.Package2;
import com.selenium.objectRepositories.Package3;
import com.selenium.utilities.DataDrivenUtils;
import com.selenium.utilities.DriverSetup;
import com.selenium.utilities.ExtentReportManager;
import com.selenium.utilities.ScreenShot;

public class TestMain {
    public static WebDriver driver;
    DriverSetup objDriver;
    String holidayWindowId;
    public ExtentReportManager erm;

    @BeforeClass
    @Parameters("browser")
    public void setUp(String browser) throws InterruptedException {
        objDriver = new DriverSetup();
        driver = objDriver.getDriver(browser);
        driver.manage().window().maximize();
       
    }
    @BeforeTest
	public void startReporter()
	   {
		erm = new ExtentReportManager();
		erm.createTest("Search Navigation Scenario Flow");
	   }

    @Test
    public void testHolidayPackages() throws Exception {
        HomePage homeObj = new HomePage(driver);
        erm.logPass("Opened yatra Home page");

        //taking Screenshot of Home page 
        ScreenShot.screenShotTC(driver, "Home Page");
        
        HolidaysPage holidayObj = new HolidaysPage(driver);
        Package1 pack1Obj = new Package1(driver);
        Package2 pack2Obj = new Package2(driver);
        Package3 pack3Obj = new Package3(driver);
      
        
        homeObj.handleLoginPopupIfPresent();
        homeObj.clickAllOffers();
        erm.logPass("Opened all offers page");
        
        homeObj.switchToHolidays();
        holidayWindowId = holidayObj.getHolidayWindow(); // capture after switch

        holidayObj.verifyHolidayPageTitle();
        holidayObj.verifyBannerText();
        holidayObj.clickOnHolidays();
        erm.logPass("Holidays page is opened");
        
        //taking Screenshot of Home page 
        ScreenShot.screenShotTC(driver, "Home Page");
        
        // Package 1
        holidayObj.clickPackage1();
        Thread.sleep(2000);
        String tab1 = pack1Obj.switchToPackageTab();
        System.out.println("Switched to Package 1 tab: " + driver.getTitle());
        erm.logPass("Package 1 page opened");

        String name1 = "";
        String price1 = "";
        try {
            name1 = pack1Obj.getDetailName();  
            price1 = pack1Obj.getDetailPrice(); 
            System.out.println("Package 1: " + name1 + " \n Price: " + price1);
            
            //writing data into excel
            DataDrivenUtils.writeDataIntoExcel(1, 1, name1);
            DataDrivenUtils.writeDataIntoExcel(1, 2, price1);
            
            //logging the status into extentReport
            erm.logPass("Package 1 details written into excel.");
            
        } catch (Exception e) {
            System.out.println("Failed to fetch Package 1 details: " + e.getMessage());
        }
        
        //taking Screenshot of package 1
        ScreenShot.screenShotTC(driver, "Package1");
        erm.logPass("Package 1 page screenshot taken");

        //switch back to halidays page
        pack1Obj.switchBackToHoliday(holidayWindowId);

        // Package 2
        holidayObj.clickPackage2();
        Thread.sleep(2000);
        String tab2 = pack1Obj.switchToPackageTab();
        System.out.println("Switched to Package 2 tab: " + driver.getTitle());
        erm.logPass("Package 2 page opened");

        String name2 = "";
        String price2 = "";
        try {
            name2 = pack2Obj.getDetailName();
            price2 = pack2Obj.getDetailPrice();
            System.out.println("Package 2: " + name2 + " | Price: " + price2);
            
            //writing data into excel
            DataDrivenUtils.writeDataIntoExcel(2, 1, name2);
            DataDrivenUtils.writeDataIntoExcel(2, 2, price2);
            
            //logging the status into extentReport
            erm.logPass("Package 2 details written");
            
        } catch (Exception e) {
            System.out.println("Failed to fetch Package 2 details: " + e.getMessage());
        }
        
        //taking Screenshot of package2
        ScreenShot.screenShotTC(driver, "Package2");
        erm.logPass("Package 2 page screenshot taken");
      
        //switch back to halidays page
        pack2Obj.switchBackToHoliday(holidayWindowId);

        // Package 3
        holidayObj.clickPackage3();
        Thread.sleep(2000);
        String tab3 = pack3Obj.switchToPackageTab();
        erm.logPass("Package 3 page opened");
        System.out.println("Switched to Package 3 tab: " + driver.getTitle());
        

        String name3 = "";
        String price3 = "";
        try {
            name3 = pack3Obj.getDetailName3();
            price3 = pack3Obj.getDetailPrice3();
            System.out.println("Package 3: " + name3 + " | Price: " + price3);
            
            //writing data into excel
            DataDrivenUtils.writeDataIntoExcel(3, 1, name3);
            DataDrivenUtils.writeDataIntoExcel(3, 2, price3);
            
            //logging the status into extentReport
            erm.logPass("Package 3 page details written into excel");
        } catch (Exception e) {
            System.out.println("Failed to fetch Package 3 details: " + e.getMessage());
        }
        
        //taking Screenshot of package 3
        ScreenShot.screenShotTC(driver, "Package3");
        erm.logPass("Package 3 page screenshot taken");
        //switch back to halidays page
        pack3Obj.switchBackToHoliday(holidayWindowId);
  
    }
    
    @AfterMethod
	   public void getResult(ITestResult result) throws Exception {
	       if(result.getStatus() == ITestResult.FAILURE) {
	    	 //MarkupHelper is used to display the output in different colors
	    	   erm.testLogger.log(Status.FAIL, MarkupHelper.createLabel(result.getName() + " - Test Case Failed", ExtentColor.RED));
	    	   erm.testLogger.log(Status.FAIL, MarkupHelper.createLabel(result.getThrowable() + " - Test Case Failed", ExtentColor.RED));
	    	   String screenshotPath = ScreenShot.screenShotTC(driver, result.getName());
	    	 //To add it in the extent report 
	    	   erm.testLogger.fail("Test Case Failed Snapshot is below " + erm.testLogger.addScreenCaptureFromPath("."+screenshotPath));	    	  
	       }
	       else if(result.getStatus() == ITestResult.SUCCESS) {
	    	   erm.testLogger.log(Status.PASS, MarkupHelper.createLabel(result.getName()+" Test Case PASSED", ExtentColor.GREEN));
	       }
	       else if(result.getStatus() == ITestResult.SKIP){
	    	   erm.testLogger.log(Status.SKIP, MarkupHelper.createLabel(result.getName() + " - Test Case Skipped", ExtentColor.ORANGE)); 
	       }
	   }
    
    @AfterClass
    public void tearDown() {
        driver.quit();
    }
    
    @AfterTest
    public void flushReport() {
	 erm.flushReports();
    }
}
