package com.selenium.utilities;
 
import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.WebDriver;
 
public class BrowserUtils {

    // Get the current window handle

    public static String getCurrentWindowHandle(WebDriver driver) {

        return driver.getWindowHandle();

    }

    // Switch to a newly opened tab

    public static String switchToMostRecentTab(WebDriver driver) {
        String currentWindowHandle = driver.getWindowHandle();
        ArrayList<String> windowHandles = new ArrayList<>(driver.getWindowHandles());

        // Remove the current window handle to avoid switching to the same tab
        windowHandles.remove(currentWindowHandle);

        if (!windowHandles.isEmpty()) {
            String mostRecentHandle = windowHandles.get(windowHandles.size() - 1);
            driver.switchTo().window(mostRecentHandle);
            return mostRecentHandle;
        }

        throw new RuntimeException("No new tab found to switch to.");
    }

 
    // Switch to any available window/tab

    public static void switchToAvailableWindow(WebDriver driver) {

        Set<String> allHandles = driver.getWindowHandles();

        for (String windowHandle : allHandles) {

            driver.switchTo().window(windowHandle);

            break; // Switch happens only once

        }

    }
 
    // Switch back to the previous tab

    public static void switchToPreviousTab(WebDriver driver, String previousWindowHandle) {

        driver.switchTo().window(previousWindowHandle);

    }
 
    // Close current tab

    public static void closeCurrentTab(WebDriver driver) {

        driver.close();

    }
 // Close current tab and switch back to the main window
    public static void closeCurrentTabAndSwitchBack(WebDriver driver, String mainWindowHandle) {
        driver.close();
        driver.switchTo().window(mainWindowHandle);
    }

    
public static String switchToNewTabAndReturnHandle(WebDriver driver) {
    String originalHandle = driver.getWindowHandle();
    Set<String> oldHandles = driver.getWindowHandles();

    for (int i = 0; i < 10; i++) {
        Set<String> newHandles = driver.getWindowHandles();
        newHandles.removeAll(oldHandles);
        if (!newHandles.isEmpty()) {
            String newTabHandle = newHandles.iterator().next();
            driver.switchTo().window(newTabHandle);
            return newTabHandle;
        }
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    throw new RuntimeException("No new tab found to switch to.");
}
}

 